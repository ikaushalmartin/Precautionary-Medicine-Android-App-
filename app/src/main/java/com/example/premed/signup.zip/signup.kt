package com.example.premed

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase


class signup : AppCompatActivity() {

    private lateinit var mAuth:FirebaseAuth
    private lateinit var refUsers:DatabaseReference
private var firebaseuserid:String=""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        var register:Button=findViewById(R.id.button2)
        mAuth = FirebaseAuth.getInstance()
        register.setOnClickListener {
            registeruser()
        }

    }

    private fun registeruser() {
        var us: EditText=findViewById(R.id.usersign)
        var ps: EditText=findViewById(R.id.editTextTextPassword2)
        var fs: EditText=findViewById(R.id.editTextTextPersonName)
        var ls:EditText=findViewById(R.id.userlog)
        var username: String =us.text.toString()
        var firstname: String=fs.text.toString()
        var lastname: String=ls.text.toString()
        var password:String=ps.text.toString()

if(username=="" || firstname=="" || lastname=="" || password==""){
    val tostext="All Fields Are Mandatory"
    val tosduration=Toast.LENGTH_LONG
    Toast.makeText(applicationContext,tostext,tosduration).show()

}
else{
            mAuth.createUserWithEmailAndPassword(username,password).addOnCompleteListener{task->
                if(task.isSuccessful) {

                    firebaseuserid = mAuth.currentUser!!.uid
                    refUsers = FirebaseDatabase.getInstance().reference.child("users").child(firebaseuserid)
                    val userhashmap = HashMap<String, Any>()
                    userhashmap["uid"] = firebaseuserid
                    userhashmap["username"] = username
                    userhashmap["firstname"] = firstname
                    userhashmap["lastname"] = lastname
                    userhashmap["password"] = password

                    refUsers.updateChildren(userhashmap).addOnCompleteListener {
                        if (task.isSuccessful) {
                            val intent = Intent(this@signup, MainActivity::class.java)
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)

                        }
                    }
                }
                else
                    {
                        val tostext="Some Error Occured! Please Try Again Later"
                        val tosduration= android.widget.Toast.LENGTH_LONG
                        android.widget.Toast.makeText(applicationContext,tostext,tosduration).show()
                    }
                }

}
        }




    }


